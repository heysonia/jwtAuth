package jwtauth.jwtauthApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtauthAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtauthAppApplication.class, args);
	}

}
