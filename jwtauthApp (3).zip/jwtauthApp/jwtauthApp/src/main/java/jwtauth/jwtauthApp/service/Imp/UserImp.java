package jwtauth.jwtauthApp.service.Imp;

import jwtauth.jwtauthApp.config.AuthConfig;
import jwtauth.jwtauthApp.dto.req.UserRequestDto;
import jwtauth.jwtauthApp.dto.resp.UserResponseDto;
import jwtauth.jwtauthApp.entity.UserEnitiy;
import jwtauth.jwtauthApp.exp.UserAlreadyExistsException;
import jwtauth.jwtauthApp.repo.UserRepo;
import jwtauth.jwtauthApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserImp implements UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private AuthConfig authConfig;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserEnitiy user = userRepo.findByEmail(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return user;
    }

    @Override
    public List<UserResponseDto> getAllUser() {
        List<UserEnitiy> userEntities = userRepo.findAll();
        return userEntities.stream()
                .map(this::convertToUserResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public UserResponseDto createUser(UserRequestDto userRequestDto) {
        Optional<UserEnitiy> foundUser = userRepo.findByEmail(userRequestDto.getEmail());
        if (foundUser.isEmpty()) {
            UserEnitiy user = convertToUserEntity(userRequestDto);
            user.setPassword(authConfig.passwordEncoder().encode(user.getPassword()));
            UserEnitiy createdUser = userRepo.save(user);
            return convertToUserResponseDto(createdUser);
        } else {
            throw new UserAlreadyExistsException("User with email " + userRequestDto.getEmail() + " already exists");
        }
    }

    private UserEnitiy convertToUserEntity(UserRequestDto userRequestDto) {
        UserEnitiy user = new UserEnitiy();
        user.setName(userRequestDto.getName());
        user.setEmail(userRequestDto.getEmail());
        user.setPassword(userRequestDto.getPassword());
        user.setGender(userRequestDto.getGender());
        return user;
    }

    private UserResponseDto convertToUserResponseDto(UserEnitiy user) {
        UserResponseDto userRespDto = new UserResponseDto();
        userRespDto.setName(user.getName());
        userRespDto.setEmail(user.getEmail());
        userRespDto.setGender(user.getGender());
        userRespDto.setId(user.getId());
        return userRespDto;
    }
}
