package jwtauth.jwtauthApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtauthAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
